from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class Doctor(models.Model):
    user = models.OneToOneField(User, null=True, on_delete=models.CASCADE)
    #doctor_id = models.IntegerField(max_length=200, null=True)
    name = models.CharField(max_length=200, null=True)
    SPECIALIZATION = (
        ('Cardiologist','Cardiologist'),('Dentist','Dentist'),('Paediatrician','Paediatrician'),('Psychiatrists','Psychiatrists'),('Neurologist','Neurologist')
    )
    specialization=models.CharField(max_length=200,blank=True,choices=SPECIALIZATION)
    email = models.CharField(max_length=200, null=True)

    def __str__(self):
        return self.name


class Patient(models.Model):
    user = models.OneToOneField(User, null=True, on_delete=models.CASCADE)
    #patient_id = models.IntegerField(max_length=20, null=True)
    name = models.CharField(max_length=200, null=True)
    email = models.CharField(max_length=200, null=True)
    def __str__(self):
        return self.name



class Appointment(models.Model):
    patient_id=models.ForeignKey(Patient,null=True,on_delete=models.CASCADE)
    doctor_id=models.ForeignKey(Doctor,null=True,on_delete=models.CASCADE)
    appointment_date=models.DateField(auto_now=False)
    approved = models.BooleanField(default=False)
    def __str__(self):
        return self.doctor_id.name

    
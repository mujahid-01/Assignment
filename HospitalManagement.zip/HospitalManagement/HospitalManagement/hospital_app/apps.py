from django.apps import AppConfig


class HospitalAppConfig(AppConfig):
    name = 'hospital_app'

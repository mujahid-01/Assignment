import django_filters
from django_filters import DateFilter
from .models import *

class DoctorFilter(django_filters.FilterSet):
    class Meta:
        model = Doctor
        fields = '__all__'
        exclude = ['user']
class PatientFilter(django_filters.FilterSet):
    class Meta:
        model = Appointment
        fields = ['appointment_date','approved']
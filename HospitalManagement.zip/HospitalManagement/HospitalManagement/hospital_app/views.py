from django.shortcuts import render, redirect
from django.forms import inlineformset_factory
from .models import *

from django.forms import forms
from . import form
from .form import appointment_form, doctor_form, patient_form, CreateUserForm, bookappointmentform, ContactusForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import Group
from django.contrib import messages
from django.core.mail import send_mail
from django import forms
from .filters import DoctorFilter, PatientFilter

from django.contrib.auth.decorators import login_required

from .decorators import unauthenticated_user, allowed_users, admin_only

# Create your views here.


def homepage(request):
    return render(request, 'hospital_app/home.html')


@login_required(login_url='login')
@admin_only
def home(request):
    doctors = Doctor.objects.all()
    patients = Patient.objects.all()
    totaldoctors = doctors.count
    totalpatients = patients.count
    context = {'doctors': doctors, 'patients': patients,
               'totaldoctors': totaldoctors, 'totalpatients': totalpatients}
    return render(request, 'hospital_app/dashboard.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def total_patients(request):
    patients = Patient.objects.all()
    context = {'patients': patients}
    return render(request, 'hospital_app/total_patients.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def doctor(request, pk_test):
    if request.POST:
        doctor = Doctor.objects.get(id=pk_test)
        patients = doctor.appointment_set.all().order_by('appointment_date')
        date = request.POST.get('date')
        totalpatients = patients.filter(appointment_date=date)
        totalpatients = totalpatients.count
        context = {'doctor': doctor, 'patients': patients,
                   'totalpatients': totalpatients}
        return render(request, 'hospital_app/doctor.html', context)
    doctor = Doctor.objects.get(id=pk_test)
    patients = doctor.appointment_set.all().order_by('appointment_date')
    context = {'doctor': doctor, 'patients': patients}
    return render(request, 'hospital_app/doctor.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def patient(request, pk_test):
    patient = Patient.objects.get(id=pk_test)
    doctors = patient.appointment_set.all().order_by('appointment_date')
    context = {'patient': patient, 'doctors': doctors}
    return render(request, 'hospital_app/patient.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def createappointment(request):
    form = appointment_form()
    if request.method == 'POST':
        form = appointment_form(request.POST)
        if form.is_valid():
            # print(form.cleaned_data['doctor_id'])
            form.save()
            return redirect('/')
    context = {'form': form}
    return render(request, 'hospital_app/appointment_form.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def updateappointment(request, pk):
    appointment = Appointment.objects.get(id=pk)
    form = appointment_form(instance=appointment)
    if request.method == 'POST':
        form = appointment_form(request.POST, instance=appointment)
        if form.is_valid():
            form.save()
            return redirect('/')
    context = {'form': form}
    return render(request, 'hospital_app/appointment_form.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def totalappointments(request):
    appointments = Appointment.objects.all().order_by('appointment_date')
    context = {'appointments': appointments}
    return render(request, 'hospital_app/total_appointments.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def deleteappointment(request, pk):
    appointment = Appointment.objects.get(id=pk)
    if request.method == 'POST':
        appointment.delete()
        return redirect('/')
    context = {'item': appointment}
    return render(request, 'hospital_app/delete_appointment.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def createdoctor(request):
    form = doctor_form()
    if request.method == 'POST':
        form = doctor_form(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    context = {'form': form}
    return render(request, 'hospital_app/create_doctor.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def createpatient(request):
    form = patient_form()
    if request.method == 'POST':
        form = patient_form(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    context = {'form': form}
    return render(request, 'hospital_app/create_patient.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def createappointmentp(request, pk):
    appointmentformset = inlineformset_factory(
        Patient, Appointment, fields=('doctor_id', 'appointment_date'), extra=5)
    patient = Patient.objects.get(id=pk)
    formset = appointmentformset(
        queryset=Appointment.objects.none(), instance=patient)
    # form = appointment_form(initial={'patient_id':patient})
    if request.method == 'POST':
        formset = appointmentformset(request.POST, instance=patient)
        # form = appointment_form(request.POST)
        if formset.is_valid():
            formset.save()
            return redirect('/')
    context = {'formset': formset}
    return render(request, 'hospital_app/patient_appointment_form.html', context)


@unauthenticated_user
def registerPage(request):

    form = CreateUserForm()
    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')

            group = Group.objects.get(name='patient')

            user.groups.add(group)
            print(request.user.username)

            Patient.objects.create(
                user=user,
                name=user.username,
                email=user.email,
            )

            messages.success(request, 'Account was created for ' + username)
            return redirect('login')
    context = {'form': form}
    return render(request, 'hospital_app/register.html', context)


@unauthenticated_user
def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.info(request, 'Username OR password is incorrect')

    context = {}
    return render(request, 'hospital_app/login.html', context)


def logoutUser(request):
    logout(request)
    return redirect('login')


@login_required(login_url='login')
def userPage(request):
    appointments = request.user.patient.appointment_set.all()

    approved = appointments.filter(approved=True).count()
    napproved = appointments.filter(approved=False).count()

    print('appointments', appointments)
    doctors = Doctor.objects.all()
    patients = Patient.objects.all()
    context = {'doctors': doctors, 'patients': patients,
               'appointments': appointments, 'approved': approved, 'notapproved': napproved}
    return render(request, 'hospital_app/user.html', context)


@allowed_users(allowed_roles=['admin'])
def doctorregisterPage(request):
    form = CreateUserForm()
    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')

            group = Group.objects.get(name='doctor')

            user.groups.add(group)
            print(request.user.username)

            Doctor.objects.create(
                user=user,
                name=user.username,
                email=user.email,
            )

            return redirect('/')

    context = {'form': form}
    return render(request, 'hospital_app/doctor_register.html', context)


@login_required(login_url='login')
def doctorPage(request):
    appointments = request.user.doctor.appointment_set.all()

    approved = appointments.filter(approved=True).count()
    napproved = appointments.filter(approved=False).count()

    myFilter2 = PatientFilter(request.GET, queryset=appointments)

    appointments = myFilter2.qs

    print('appointments', appointments)
    context = {'appointments': appointments, 'approved': approved,
               'notapproved': napproved, 'myFilter2': myFilter2}
    return render(request, 'hospital_app/doctor_user.html', context)


@login_required(login_url='login')
# @patient_only
def bookappointment(request):
	patients = Patient.objects.all()
	doctors = Doctor.objects.all()

	myFilter = DoctorFilter(request.GET,queryset=doctors)

	doctors = myFilter.qs

	context = {'doctors': doctors,'patients':patients,'myFilter':myFilter}
	return render(request, 'hospital_app/book_appointment.html',context)


@login_required(login_url='login')
def bookdoctor(request, pk2):
    patient = request.user.patient
    doctor = Doctor.objects.get(id=pk2)
    form = bookappointmentform()
    if request.method == 'POST':
        form = bookappointmentform(request.POST)
        if form.is_valid():
            appointmentdate = form.cleaned_data.get('appointment_date')

            Appointment.objects.create(
                patient_id=patient,
                doctor_id=doctor,
                appointment_date=appointmentdate,
            )

    context = {'form': form}
    return render(request, 'hospital_app/book_appointment_form.html', context)


@allowed_users(allowed_roles=['admin'])
def patientregisterPage(request):
    form = CreateUserForm()
    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')

            group = Group.objects.get(name='patient')

            user.groups.add(group)
            print(request.user.username)

            Patient.objects.create(
                user=user,
                name=user.username,
                email=user.email,
            )

            return redirect('/')

    context = {'form': form}
    return render(request, 'hospital_app/patient_register.html', context)


def aboutus_view(request):
    return render(request, 'hospital_app/aboutus.html')


def contactus_view(request):
    return render(request, 'hospital_app/contactus.html')


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def patientdetails(request, pk_test):
    appointments = Appointment.objects.filter(patient_id=pk_test)
    approved = appointments.filter(approved=True).count()
    napproved = appointments.filter(approved=False).count()

    context = {'appointments': appointments,'approved':approved,'notapproved':napproved}
    return render(request, 'hospital_app/patientdetails.html', context)

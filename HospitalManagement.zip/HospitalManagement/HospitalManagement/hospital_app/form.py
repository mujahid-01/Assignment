from django.forms import ModelForm
from django import forms
from .models import *
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms

class DateInput(forms.DateInput):
        input_type = 'date'

class appointment_form(ModelForm):
    class Meta:
        # widgets = {'appointment_date' : DateInput()}
        model = Appointment
        fields='__all__'
    
class doctor_form(ModelForm):
    class Meta:
        model = Doctor
        fields='__all__'
    
class patient_form(ModelForm):
    class Meta:
        model = Patient
        fields='__all__'

class CreateUserForm(UserCreationForm):
    	class Meta:
            model = User
            fields = ['username', 'email', 'password1', 'password2']

class bookappointmentform(forms.Form):
    appointment_date=forms.DateField()

class ContactusForm(forms.Form):
    Name = forms.CharField(max_length=30)
    Email = forms.EmailField()
    Message = forms.CharField(max_length=500,widget=forms.Textarea(attrs={'rows': 3, 'cols': 30}))